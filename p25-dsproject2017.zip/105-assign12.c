//Stores the genre of the most played song
void favouriteSong(TOPTEN* headTopTen){
	TOPTEN* temp=headTopTen;
	char genre[20];
	strcpy(genre,temp->genre);
}
//Function predicts the most favorable song based on genre of your most played song
void predictions(TOPTEN* headTopTen, char genre[]){
	FILE *fp=fopen("global.txt","r");
	char str[100];
	int f=0;
	while(fscanf(fp," %[^\n]s",str)>=0){
		int l=strlen(str),count=0;
		char song[100],artist[100],album[100],genre2[100],num[100];
		int i,k=0,j,n=0,m=0;
		for(i=0;i<l;i++){
			if(str[i]=='^'){
				if(count==0) song[k]='\0';
				else if(count==1) artist[k]='\0';
				else if(count==2) album[k]='\0';
				else if(count==3) genre2[k]='\0';
				k=0;
				count++;
			}
			if(str[i]!='^' && count==0){
				song[k++]=str[i];
			}
			else if(str[i]!='^' && count==1){
				artist[k++]=str[i];
			}
			else if(str[i]!='^' && count==2){
				album[k++]=str[i];
			}
			else if(str[i]!='^' && count==3){
				genre2[k++]=str[i];
			}
			else if(str[i]=='#'){
				for(j=i+1;j<l;j++){
						num[m++]=str[j];
					}
					num[m]='\0';
					n=atoi(num);
					m=0;
					break;
			}
		}
		if(strcmp(genre,genre2)==0){
			createList(str,f);//Creates a list of all songs of the matching genre
			f++;
		}
	}
}


void userFile(char ch[])
{
    FILE *fp=fopen(ch,"a");
    FILE *G=fopen("global.txt","r");
    choices(ch);

}
void addToUser(char ch[]){
	FILE *fp=fopen("global.txt","r");
	FILE *fp2=fopen(ch,"a+");
	char str[100];
	while(fscanf(fp," %[^\n]s",str)>=0){
		int l=strlen(str),count=0;
		char song[100],artist[100],album[100],genre2[100],num[100];
		int i,k=0,j,n=0,m=0;
		for(i=0;i<l;i++){
			if(str[i]=='^'){
				if(count==0) song[k]='\0';
				else if(count==1) artist[k]='\0';
				else if(count==2) album[k]='\0';
				else if(count==3) genre2[k]='\0';
				k=0;
				count++;
			}
			if(str[i]!='^' && count==0){
				song[k++]=str[i];
			}
			else if(str[i]!='^' && count==1){
				artist[k++]=str[i];
			}
			else if(str[i]!='^' && count==2){
				album[k++]=str[i];
			}
			else if(str[i]!='^' && count==3){
				genre2[k++]=str[i];
			}
			else if(str[i]=='#'){
				for(j=i+1;j<l;j++){
						num[m++]=str[j];
					}
					num[m]='\0';
					n=atoi(num);
					m=0;
					break;
			}
		}

		if(n==1) fprintf(fp2,"%s",str);
		if(n!=1) break;
	}
	fclose(fp);
	fclose(fp2);
}

void loginScreen(){
	char pws[100],pwe[100],ch[100];
	int i=0;
	char c=' ';
	printf("Enter Username\n");
	scanf("%s",ch);
	strcat(ch,".txt");
	FILE *fp=fopen(ch,"r");
	printf("Enter password\n");
	getchar();
    	while(i<=100) {
        	c = getch();
		pwe[i]=c;
        	if(c=='\n')
        	{
            		break;
        	}
        	else
        	{
            		printf("*");//Prints a * character for every new password you enter
        	}
	i++;
  	}
   	pwe[i]='\0';
	fscanf(fp,"%s",pws);
	i=0;
	//The loop encodes the password in the format you
	for(i=0;i<strlen(pws);i++)
	{
		if(i%2==0)
		{
			pws[i]=pws[i]-3;
		}
		else
		{
			pws[i]=pws[i]+3;
		}
	}
	if(strcmp(pws,pwe)==0)
	{
	    system("clear");
	    loading("Logging In..",1000);
		if(strcmp(ch,"admin.txt")!=0)
		{
			printf("\nYou are logged in\n");
			addToUser(ch);
			//fclose(fp);
			system("clear");
			userFile(ch);
		}
		else
		{
			adminAccess();
		}
	}
	else
    	{
		char o;
		printf("\nIncorrect Username or Password combination\nTry Again(y/n)");
		fflush(stdin);
		scanf("%c",&o);
		if(o=='y'||o=='Y')
		{
		    system("clear");
		    loginScreen();
		}
		else if(o=='n'||o=='N')
		{
		    system("clear");
		    startScreen();
		}

    	}
}
//Writing all the existing songs into the newly added user
void writeinFile(char ch[])
{
	FILE *fp=fopen("global.txt","r");
	FILE *fp2=fopen(ch,"a");
	char ch1[100];
	fprintf(fp2, "\n");
	while(fscanf(fp," %[^\n]s",ch1)>=0)
	{
		int i=0;
		char str[100];
		while(ch1[i]!='#')
		{
			str[i]=ch1[i];
			i++;
		}
		str[i]='\0';
		strcat(str,"#0");
		//printf("%s\n",str );
		fprintf(fp2,"%s\n",str);
	}
	fclose(fp2);

}
//Adds every user who creates a new account into the file database
void writeinAdmin(char ch[])
{
	FILE *fp=fopen("admin.txt","a");
	fprintf(fp,"%s\n",ch);
	fclose(fp);
}
void createAccount(){
	char ch[100],pw[100];
	char c=' ';
	int i=0;;
	printf("Enter your unique username\n");
	scanf("%s",ch);
	strcat(ch,".txt");
	FILE *fp=fopen(ch,"a");
	printf("Enter your password\n");
	getchar();
	//Encrypting the password
    	while(i<=100) {
        	c = getch();
		pw[i]=c;
        	if(c=='\n')
        	{
            		break;
        	}
        	else
        	{
            		printf("*");
        	}
	i++;
   }
   pw[i]='\0';
    loading("Creating",1000);
    for(i=0;i<strlen(pw);i++)
    {
    	if(i%2==0)
    	{
			fprintf(fp, "%c", pw[i]+3);
		}
		else
		{
			fprintf(fp, "%c", pw[i]-3);
		}
	}
	fclose(fp);
	writeinFile(ch);
	writeinAdmin(ch);
	printf("\nAccount successfully created!\nPress 1 to go back to main screen and 2 to log in.");
	scanf("%d",&i);
	if(i==1)
    {
        startScreen();
    }
    else if(i==2)
    {
        loginScreen();
    }
    else
    {
        printf("\nInvalid input\n");
    }
}

void loading(char ch[],int speed){//Loading animation
	fflush(stdin);
	fflush(stdout);
	int i=0,n=0,pos=0,choice=0;
	char percentage='%';
	while(n<=100){
		static char bars[]={'/','-','\\','|'};
		static int nbars=sizeof(bars)/sizeof(char);
		printf("%s   ",ch);
		for(i=0;i<n;i++) printf("#");
		for(i=0;i<100-n;i++) printf(".");
		printf("%c %d%c\r",bars[pos],n,percentage);
		pos=(pos+1)%nbars;
		if(pos==0) n+=1;
		if(n!=0) usleep(13000);
	}
	printf("\nDone\n");
}
void startScreen(){
	//makeMenu();
	//choices();
	//display(headTopTen);
	int i;
	printf("Press 1 to create a new account\n");
	printf("Press 2 to log in\n");
	printf("Press 3 to exit\n");
	scanf("%d",&i);
	if(i==1)
	{
		system("clear");
		createAccount();
	}
	else if(i==2)
	{
		system("clear");
		loginScreen();
	}
	else if(i==3)
    {
        exit(0);
    }
	else
    {
        printf("\nInvalid input\n");
    }
}
