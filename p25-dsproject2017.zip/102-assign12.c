#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <termios.h>

/*
  This function provides the animation for playing music
*/
void musicBar(){
  fflush(stdin);
  fflush(stdout);
  int i=0,n=0,pos=0,choice=0;
  char percentage='%';
  while(n<=100){
    static char bars[]={'/','-','\\','|'};
    static int nbars=sizeof(bars)/sizeof(char);
    for(i=0;i<n;i++) printf("_");
    for(i=0;i<100-n;i++) printf(".");
    printf("%c %d%c\r",bars[pos],n,percentage);
    pos=(pos+1)%nbars;
    if(pos==0) n+=1;
    if(n!=0) usleep(13000);
  }
  printf("\nDone\n");
}

/*
  used to use getchar() in C
*/
int getch() {
    struct termios oldtc, newtc;
    int c;
    tcgetattr(STDIN_FILENO, &oldtc);
    newtc = oldtc;
    newtc.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newtc);
    c=getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldtc);
    return c;
}


//This is to change all the uppercase in a string to lowercase 
void caselow(char str[100],int l){
    int i;
    for(i=0;i<l;i++){
        if(str[i]>='A'&&str[i]<='Z'){
            str[i]+='a'-'A';
        }
    }
}
//This function is to search for anything present in the song database. 
void search(char usr[100]){
    char buff[1000000],user[1000],bufr[1000000],ch='y',ser[100];
    int flag1=1,key=0;

    //The below loop is keep prompting search until he user wants to.
    while(ch=='y'){
      system("clear");
      strcpy(user,usr);
      user[strlen(user)-4]=0;
      printf("----------------------------------------Welcome %s------------------------------------------\n\n\n",user);
      
      //The key is to know the refine criteria which you selected
      switch(key){
        case 1:printf("         Search refined to song\n");break;
        case 2:printf("         Search refined to artist\n");break;
        case 3:printf("         Search refined to album\n");break;
        case 4:printf("         Search refined to genre\n");break;
      }

      //flag1 is to know if you have any refinements
      if(flag1==1){
        printf("Search for:");
        fflush(stdin);

        scanf(" %[^\n]s",ser);
      }
      else{
        printf("Searched For:%s\n",ser);
      }
      flag1=1;
      int l=strlen(ser),flag=0,i,j,k,count=0;
      caselow(ser,l);
      FILE *fp;
      fp = fopen("global.txt", "r");

      //One by one lines are taken as input
      while(fgets(buff, 1000, fp)) {
        k=0;
        if(key!=0){
          for(i=0;k<key-1;i++){
              if(buff[i]=='^')k++;
          }
          for(k=0;buff[i]!='^';i++){
            bufr[k]=buff[i];
            k++;
          }
          bufr[k]=0;
        }
        else strcpy(bufr,buff);
        for(i=0;i<=strlen(bufr)-l&&strlen(bufr)>=l;i++){
          flag=0;
          for(j=0;j<l;j++){
              if(ser[j]!=bufr[i+j])flag=1;
          }
          k=i;
          if(flag==0 &&(i==0 || buff[i-1]==' '|| buff[i-1]=='^' || buff[i-1]=='\(' )){
            while(k!=-1)k--;
            k++;
            printf("%d.)",count+1);

            //The songs matched are sen to be in a linked list
            createList(buff,count);
            count++;
            //Printing the songs
            printf("SONG: ");
            while(buff[k]!='^'){
              if(k==0||buff[k-1]==' ')printf("%c",buff[k]-'a'+'A');
              else printf("%c",buff[k]);
              k++;
            }
            printf("\n   ARTIST: ");
            i+=l;
            k++;
            while(buff[k]!='^'){
              if((buff[k-1]==' '||buff[k-1]=='^'||buff[k-1]=='.')&&(buff[k]>='a'&&buff[k]<='z'))printf("%c",buff[k]-'a'+'A');
              else printf("%c",buff[k]);
              k++;
            }
            printf(" ALBUM: ");
            k++;
            while(buff[k]!='^'){
              if((buff[k-1]==' '||buff[k-1]=='^'||buff[k-1]=='.')&&(buff[k]>='a'&&buff[k]<='z'))printf("%c",buff[k]-'a'+'A');
              else printf("%c",buff[k]);
              k++;
            }
            printf(" GENRE: ");
            k++;
            while(buff[k]!='^'){
              if((buff[k-1]==' '||buff[k-1]=='^'||buff[k-1]=='.')&&(buff[k]>='a'&&buff[k]<='z'))printf("%c",buff[k]-'a'+'A');
              else printf("%c",buff[k]);
              k++;
            }
            printf("\n");
            break;
        }
      }
}
   fclose(fp);
   if(count!=0){
    fflush(stdin);
    printf("Do you want to refine your search\n\nEnter \n1 to search by song name\n2 to search by artist\n3 to search by album\n4 to search by genre\n5 to remove any constraints\n0 to exit refine\nYour option:");
    scanf(" %d",&key);
    if(key!=0){
     flag1=0;
      if(key==5)key=0;
      count=0;
      continue;
     }
    }
    else {
    printf("Your search returned no results\n");
    key=0;
    }
   printf("\n\nWant to search again\nEnter y to search again:");
   fflush(stdin);
   getch();
   scanf("%c",&ch);
   fflush(stdin);
  }
playMusic(4,usr);
}
