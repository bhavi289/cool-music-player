/*PRATHYUSH.P
201601063,P025,MUSIC PLAYER,TASK-ADMIN FUNCTIONS*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct allSongs{
	int sno;
	char song[20];
	char artist[20];
	char album[20];
	char genre[10];
	int times;
	struct allSongs* next;
}ALLSONGS;

typedef struct list{
    char A[1000];
    struct list* next;
}LIST;

LIST *head;
ALLSONGS *allSongshead,*allSongslast;

ALLSONGS* createNode1(char[],char[],char[],char[],int,int );
void createList2(char[],int,int);
LIST* createNode2(char[]);
void genSongsDatabase(FILE*);
void editSong(char[],char[]);
void deleteSong(char[],char[],char[],char[]);
void addSong();
void adminAccess();
void show(int);


int main(){

	adminAccess();
}

//creates linked list for editSong,deleteSong,show operation
ALLSONGS* createNode1(char song[],char artist[],char album[],char genre[],int sno,int times){
	ALLSONGS *temp;
	temp = (ALLSONGS*)malloc(sizeof(ALLSONGS));
	temp->sno=sno+1;
	strcpy(temp->song,song);
	strcpy(temp->artist,artist);
	strcpy(temp->album,album);
	strcpy(temp->genre,genre);
	temp->times=times;
	temp->next = NULL;
	return temp;
}


//initiating linked list for editSong,deleteSong,show operation
void createList2(char str[],int sno,int counter){

	int l=strlen(str),count=0;int times;
	char song[20],artist[20],album[20],genre[20];
	int i,k=0;
	static int f=0;char temp[10];
	for(i=0;i<l;i++){
		if(str[i]=='^'){
			if(count==0) song[k]='\0';
			else if(count==1) artist[k]='\0';
			else if(count==2) album[k]='\0';
			else if(count==3) genre[k]='\0';
			//else if(count==4) temp[k]='\0';
			k=0;
			count++;
		}
		if(str[i]!='^' && count==0){
			song[k++]=str[i];
		}
		else if(str[i]!='^' && count==1){
			artist[k++]=str[i];
		}
		else if(str[i]!='^' && count==2){
			album[k++]=str[i];
		}
		else if(str[i]!='^' && count==3){
			genre[k++]=str[i];
		}
		else if(str[i]=='#'){
            i+=1;
            while(i<l)
            {
                temp[k++]=str[i];
                i++;
            }
            times=atoi(temp);
		}
	}
	ALLSONGS *p;
	p=createNode1(song,artist,album,genre,sno,times);
	if(counter==0){
		allSongslast=allSongshead=p;
		f++;
	}
	else{
		allSongslast->next=p;
		allSongslast=p;
	}
}

//creates linked list for addSong operation
LIST* createNode2(char ch[]){
    LIST* temp;

    temp=(LIST*)malloc(sizeof(LIST));
    strcpy(temp->A,ch);
    return temp;
}

//initiating linked list for addSong operation
void genSongsDatabase(FILE *fp){

    int i=0;char ch[100];
    LIST *last,*p;

    while(fscanf(fp," %[^\n]s",ch)>=0)
    {
        p=createNode2(ch);
        if(i==0){
            last=head=p;
            i++;
        }
        else{
            last->next=p;
            last=p;
        }
    }
    fclose(fp);
}

void editSong(char editsongname[], char editsongartist[]){
      ALLSONGS *temp;
      temp=allSongshead;int flag=0,want;
      char newname[20],newartist[20],newalbum[20],newgenre[10];

//traversing through linked list and editing the particular node if found
      while(temp!=NULL)
      {
          if ((strcmp(temp->song,editsongname)==0)&&(strcmp(temp->artist,editsongartist)==0))   //for all nodes except last one
          {
                printf("\nDo you want to edit the song name? Type 1 for yes or 0 for no: ");
                scanf("%d",&want);
                if(want==1)
                {
                    printf("\nEnter the New song name: ");
                    scanf(" %[^\n]s",newname);
                    strcpy(temp->song,newname);
                }
                else if(want==0)
                {
                    strcpy(newname,temp->song);
                }
                else if(want!=1 && want!=0)
                {
                    printf("\nYou entered an invalid choice..Redirecting to Main Menu...");
                    exit(0);
                }
                printf("\nDo you want to edit the song's artist name? Type 1 for yes or 0 for no: ");
                scanf("%d",&want);
                if(want==1)
                {
                    printf("\nEnter the New artist name: ");
                    scanf(" %[^\n]s",newartist);
                    strcpy(temp->artist,newartist);
                }
                else if(want==0)
                {
                    strcpy(newartist,temp->artist);
                }
                else if(want!=1 && want!=0)
                {
                    printf("\nYou entered an invalid choice..Redirecting to Main Menu...");
                    exit(0);
                }
                printf("\nDo you want to edit the song's album name? Type 1 for yes or 0 for no: ");
                scanf("%d",&want);
                if(want==1)
                {
                    printf("\nEnter the New album name: ");
                    scanf(" %[^\n]s",newalbum);
                    strcpy(temp->album,newalbum);
                }
                else if(want==0)
                {
                    strcpy(newalbum,temp->album);
                }
                else if(want!=1 && want!=0)
                {
                    printf("\nYou entered an invalid choice..Redirecting to Main Menu...");
                    exit(0);
                }
                printf("\nDo you want to edit the song's genre? Type 1 for yes or 0 for no: ");
                scanf("%d",&want);
                if(want==1)
                {
                    printf("\nEnter the New genre: ");
                    scanf(" %[^\n]s",newgenre);
                    strcpy(temp->genre,newgenre);
                }
                else if(want==0)
                {
                    strcpy(newgenre,temp->genre);
                }
                else if(want!=1 && want!=0)
                {
                    printf("\nYou entered an invalid choice..Redirecting to Main Menu...");
                    exit(0);
                }

                flag=1;
          }
          if(temp!=NULL)
            {
                temp=temp->next;
            }
          else if(flag==1)
            {break;}
          else
            {break;}
      }

          if(flag==1)
            {
                printf("\nSong Successfully edited in database.Redirecting to Main Menu...\n");
            }
          else
            {
                printf("\nSong not found..Try entering the details correctly..Redirecting to Main Menu...\n");
            }

//writing the edited linked list into global.txt file
	FILE *fp2 = fopen("global.txt", "w");
	temp=allSongshead;
	  while (temp != NULL) {
		fwrite (temp->song,strlen(temp->song), 1, fp2);
		fwrite("^",strlen("^"),1,fp2);
		fwrite(temp->artist,strlen(temp->artist),1,fp2);
		fwrite("^",strlen("^"),1,fp2);
		fwrite(temp->album,strlen(temp->album),1,fp2);
		fwrite("^",strlen("^"),1,fp2);
		fwrite(temp->genre,strlen(temp->genre),1,fp2);
		fwrite("^ #",strlen("^ #"),1,fp2);
		fprintf(fp2, "%d", temp->times);
		fwrite("\n",strlen("\n"),1,fp2);
		temp = temp->next;
	}
	free(temp);
	fclose(fp2);

//opening admin file and reading each file name and also each file's content and storing that file's content into a linked list
	   int i=0;char chh[100];
       FILE *abc=fopen("admin.txt","r");
       fscanf(abc," %[^\n]s",chh);

    	while(fscanf(abc," %[^\n]s",chh)>=0){
         		int counter=0;
          		FILE *fp=fopen(chh,"r");
				char ch1[100];
				char pw1[100];
				fscanf(fp," %[^\n]s",pw1);
				while(fscanf(fp," %[^\n]s",ch1)>=0){
		               		createList2(ch1,i,counter);
		               		counter++;
                       		i++;
                }
        fclose(fp);
        temp=allSongshead;

        //editing the node of linked list
        while(temp!=NULL)
        {
          if ((strcmp(temp->song,editsongname)==0)&&(strcmp(temp->artist,editsongartist)==0))
          {
                strcpy(temp->song,newname);
                strcpy(temp->artist,newartist);
                strcpy(temp->album,newalbum);
                strcpy(temp->genre,newgenre);
                flag=1;
          }
          if(temp!=NULL)
            {
                temp=temp->next;
            }
          else if(flag==1)
            {break;}
          else
            {break;}
      }

     //writing into each file the edited linked list
    FILE *fp2 = fopen(chh, "w");
	fprintf(fp2,"%s\n",pw1);

	temp=allSongshead;
    while (temp != NULL) {
    fwrite (temp->song,strlen(temp->song), 1, fp2);
    fwrite("^",strlen("^"),1,fp2);
    fwrite(temp->artist,strlen(temp->artist),1,fp2);
    fwrite("^",strlen("^"),1,fp2);
    fwrite(temp->album,strlen(temp->album),1,fp2);
    fwrite("^",strlen("^"),1,fp2);
    fwrite(temp->genre,strlen(temp->genre),1,fp2);
    fwrite("^ #",strlen("^ #"),1,fp2);
    fprintf(fp2, "%d", temp->times);
    fwrite("\n",strlen("\n"),1,fp2);
    temp = temp->next;
    }
	fclose(fp2);
	free(temp);
}
}

void deleteSong(char delsongname[], char delsongartist[],char ch[],char pw[]){
      ALLSONGS *temp,*temp2;
      temp=allSongshead;
      int flag=0;

//traversing through linked list and deleting the particular node if found
//for head node
      while(temp->next!=NULL)
      {
          if ((strcmp(temp->song,delsongname)==0)&&(strcmp(temp->artist,delsongartist)==0))
          {
              allSongshead=temp->next;
              free(temp);
              temp=allSongshead;
              flag=1;
          }
          //for normal nodes
          else if ((strcmp(temp->next->song,delsongname)==0)&&(strcmp(temp->next->artist,delsongartist)==0))
          {
                temp->next=temp->next->next;
                flag=1;
          }

        if(temp->next!=NULL)
            {
                temp=temp->next;
            }
        else if(flag==1)
            {break;}
        else{break;}
       }
//for last node
      if (temp->next==NULL)
          {
              if((strcmp(temp->song,delsongname)==0)&&(strcmp(temp->artist,delsongartist)==0))
             {
                free(temp);
                flag=1;
             }
          }
          if(flag==1)
            {
                printf("\nSong Successfully deleted from database.Redirecting to Main Menu...\n");
            }
          else
            {
                printf("\nSong not found..Try entering the details correctly..Redirecting to Main Menu...\n");
            }
 //writing the new linked list into all files
	FILE *fp2 = fopen(ch, "w");
//if file is not global then printing password of user into the file
	if(strcmp(ch,"global.txt")!=0)
	{
		fclose(fp2);
		FILE *fp2 = fopen(ch, "w");
		fprintf(fp2,"%s\n",pw);
	}
	temp=allSongshead;
      while (temp != NULL) {
    fwrite (temp->song,strlen(temp->song), 1, fp2);
    fwrite("^",strlen("^"),1,fp2);
    fwrite(temp->artist,strlen(temp->artist),1,fp2);
    fwrite("^",strlen("^"),1,fp2);
    fwrite(temp->album,strlen(temp->album),1,fp2);
    fwrite("^",strlen("^"),1,fp2);
    fwrite(temp->genre,strlen(temp->genre),1,fp2);
    fwrite("^ #",strlen("^ #"),1,fp2);
    fprintf(fp2, "%d", temp->times);
    fwrite("\n",strlen("\n"),1,fp2);
    temp = temp->next;
    }
	fclose(fp2);
    free(temp);
}

void show(int input){
      ALLSONGS *temp;
      temp=allSongshead;
      int flag=0;

      while(temp!=NULL)
      {
          if (temp->sno==input)
          {
            printf("\nSongname-%s\nArtist-%s\nAlbum-%s\nGenre-%s\n",temp->song,temp->artist,temp->album,temp->genre);
            flag=1;
            break;
          }
          if(temp!=NULL)
            {temp=temp->next;}
}
        if(flag==0)
        {
            printf("\nEnter Serial Number correctly.Redirecting to Main Menu..." );
        }
}

void addSong(){
    char newsong[20],newartist[20],newalbum[20],newgenre[10],songline[80];
//take details of new song and store them into a string
    printf("\nEnter Song Name : ");
    scanf(" %[^\n]s", newsong);
    printf("\nEnter Song Artist : ");
    scanf(" %[^\n]s", newartist);
    printf("\nEnter Song Album : ");
    scanf(" %[^\n]s", newalbum);
    printf("\nEnter Genre : ");
    scanf(" %[^\n]s", newgenre);
    strcpy(songline,newsong);
    strcat(songline,"^");
    strcat(songline,newartist);
    strcat(songline,"^");
    strcat(songline,newalbum);
    strcat(songline,"^");
    strcat(songline,newgenre);
    strcat(songline,"^");
    strcat(songline," #0");
    printf("\nSong successfully Added.Redirecting to Main Menu...\n");

//adding node to linked list
    LIST *new = NULL;
    new = (LIST *)malloc(sizeof(LIST));
    strcpy(new->A,songline);
    new->next = head;
    head=new;

//writing into global.txt file and all user files
    FILE *fp1 = fopen("global.txt", "w");
    while (head != NULL) {
    fwrite (head->A,strlen(head->A), 1, fp1);
    fwrite("\n",strlen("\n"),1,fp1);
    head = head->next;
    }
    fclose(fp1);
    FILE *abc=fopen("admin.txt","r");
    char pw[100];
    fscanf(abc," %[^\n]s",pw);
    char ch[100];
    while(fscanf(abc," %[^\n]s",ch)>=0)
    {
    	FILE *fp1=fopen(ch,"a");
    	fprintf(fp1,"%s\n",songline);
    }
    fclose(abc);
}

void adminAccess()
{
        int choice,cont =2;
        int counter=0;

        while(cont == 2)
        {
         FILE *fp=fopen("global.txt","r");

         //show menu to the user
         printf("\n****************WELCOME ADMIN***************\n");
         printf("\nSETTINGS: \n");
         printf("\n1. ADD A SONG\n");
         printf("\n2. DELETE A SONG\n");
         printf("\n3. EDIT A SONG\n");
         printf("\n4. DISPLAY ALL SONGS\n");
         printf("\nEnter your choice number: ");
         scanf("%d", &choice);

        switch(choice)
        {
            case 1:
                genSongsDatabase(fp);
                addSong();
                break;
            case 2:
                {
                    int i=0;char delsongname[20],delsongartist[20];char ch[80];
                    ALLSONGS *temp=NULL;
                    counter=0;
                    while(fscanf(fp," %[^\n]s",ch)>=0){
                    //   printf("%s \n",ch);
                        createList2(ch,i,counter);
                        counter++;
                        i++;
                    }
                    fclose(fp);
                    //printf("%s\n",allSongshead->song);
                    temp=allSongshead;
                    printf("S.no Songname Artist  Album  Genre\n");
                    while(temp!=NULL){
                        printf("%d.) %s       %s       %s       %s\n",temp->sno,temp->song,temp->artist,temp->album,temp->genre);
                        temp = temp->next;
                    }
                    printf("\nEnter the Song's Name you want to delete:");
                    scanf(" %[^\n]s", delsongname);
                    printf("Enter the Song's Artist name you want to delete:");
                    scanf(" %[^\n]s", delsongartist);
                    deleteSong(delsongname,delsongartist,"global.txt","none"); //writes into global.txt file

			i=0;
			FILE *abc=fopen("admin.txt","r");
			fscanf(abc," %[^\n]s",ch);
			while(fscanf(abc," %[^\n]s",ch)>=0){
				counter=0;
                   		FILE *fp=fopen(ch,"r");
				char ch1[100];
				char pw[100];
				fscanf(fp," %[^\n]s",pw);
				while(fscanf(fp," %[^\n]s",ch1)>=0){
		               		createList2(ch1,i,counter);
		               		counter++;
		          		i++;
		          	}
				fclose(fp);
				deleteSong(delsongname,delsongartist,ch,pw); //writes into every user file
                    	}
			fclose(abc);
                }
                break;
               case 3:
                {
                    int i=0;char editsongname[20],editsongartist[20];char ch[80];
                    ALLSONGS *temp=NULL;
                    counter=0;
//read global.txt for all songs and create a linked list
                    while(fscanf(fp," %[^\n]s",ch)>=0){
                        createList2(ch,i,counter);
                        counter++;
                        i++;
                    }
                    fclose(fp);
                    temp=allSongshead;
                    printf("S.no Songname Artist  Album  Genre\n");
                    while(temp!=NULL){
                        printf("%d.) %s     %s     %s     %s\n",temp->sno,temp->song,temp->artist,temp->album,temp->genre);
                        temp = temp->next;
                    }
//enter songname and song artist to be edited
                    printf("\nEnter the Song's Name you want to edit:");
                    scanf(" %[^\n]s", editsongname);
                    printf("Enter the Song's Artist name you want to edit:");
                    scanf(" %[^\n]s", editsongartist);
                    editSong(editsongname,editsongartist);
               }
                break;

               case 4:
                {
                    int i=0;char ch[80];int input;
                    ALLSONGS *temp=NULL;
                    counter=0;
//read global.txt for a  songs and create a linked list
                    while(fscanf(fp," %[^\n]s",ch)>=0){
                        createList2(ch,i,counter);
                        counter++;
                        i++;
                    }
                    fclose(fp);
                    temp=allSongshead;
//display those songs
                    printf("S.no Songname \n");
                    while(temp!=NULL){
                        printf("%d.) %s\n",temp->sno,temp->song);
                        temp = temp->next;
                    }
                    printf("Enter a serial number of song name to view more about it.Else type 0 to exit: ");
                    scanf("%d",&input);
                    if(input==0)
                    {
                        break;
                    }
                    else
                    {
                       show(input);
                    }

                }
                break;
            default:
                printf("You entered an invalid choice.Redirecting To Main Menu...");
            }
        printf("\n\nWant to exit? Type 1 to EXIT.Type 2 to continue to Main Menu: ");
        scanf("%d", &cont);
    }
}


















