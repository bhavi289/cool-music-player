#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <termios.h>

/*
	This function is used to increment the count of the song that has been played by the user.
	This function is called to increment the song count in the main file- "global.txt" & all the user files that have been reated 
	whenever a user signs up.
*/
void increment(char sname[], char sartist[], char fname[], int flag){
	FILE *fp=fopen(fname,"r");
	FILE *fp2=fopen("global1.txt","w");
	char str[100];
	if(strcmp(fname,"global.txt")!=0){
		fscanf(fp," %[^\n]s",str);
		fprintf(fp2,"%s\n",str);
	}
	while(fscanf(fp," %[^\n]s",str)>=1){
		char song[20],artist[20],album[20],genre[20],num[20];
		int i,k=0,l=strlen(str),n,j,count=0,m=0;
		int f=0;
		for(i=0;i<l;i++){
			if(str[i]=='^'){
				if(count==0) song[k]='\0';
				else if(count==1) artist[k]='\0';
				else if(count==2) album[k]='\0';
				else if(count==3) genre[k]='\0';
				k=0;
				count++;
			}
			if(str[i]!='^' && count==0){
				song[k++]=str[i];
			}
			else if(str[i]!='^' && count==1){
				artist[k++]=str[i];
			}
			else if(str[i]!='^' && count==2){
				album[k++]=str[i];
			}
			else if(str[i]!='^' && count==3){
				genre[k++]=str[i];
			}
			else if(str[i]=='#'){
				for(j=i+1;j<l;j++){
					num[m++]=str[j];
					num[m]='\0';
					n=atoi(num);
				}
				m=0;
				break;
			}
		}
		if(strcmp(sname,song)==0 && strcmp(sartist,artist)==0){
			char str2[100],temp;
			strcpy(str2,"");
			n++;
			int rev=0;
			m=0;
			while(n!=0){
				num[m++]=(n%10)+48;
				n/=10;
			}
			k=m-1;
			for(i=0;i<=(m-1)/2;i++){
				temp=num[i];
				num[i]=num[k];
				num[k]=temp;
				k--;
			}
			num[m]='\0';
			strcat(str2,song);
			strcat(str2,"^");
			strcat(str2,artist);
			strcat(str2,"^");
			strcat(str2,album);
			strcat(str2,"^");
			strcat(str2,genre);
			strcat(str2,"^");
			strcat(str2," #");
			strcat(str2,num);
			fprintf(fp2,"%s\n",str2);
		}
		else fprintf(fp2,"%s\n",str);
	}
	rename("global1.txt",fname);
	fclose(fp);
	fclose(fp2);
}
/*
	Function used to play previous song to current song with help of linked list
*/
void prevSong(TOPTEN* current,int flag,char ch[]){
	TOPTEN *temp=headTopTen;
	while(temp!=NULL){
		if(temp==current){
			printf("NO PREVIOUS SONG\n");
			break;
		}
		if(temp->next==current){
			printf("PLAYING %s, %s\n",temp->song,temp->artist);
			musicBar();
			increment(temp->song,temp->artist,"global.txt",flag);
			increment(temp->song,temp->artist,ch,flag);
			break;
		}
		temp=temp->next;
	}
	printf("Enter 1 for Previous Song, 2 to Repeat Current Song, 3 for next song, 4 for Back, 5 for Main Menu\n");
	int choice;
	scanf("%d",&choice);
	if(choice==1) prevSong(temp,flag,ch);
	else if(choice==2) currentSong(temp,flag,ch);
	else if(choice==3) nextSong(temp,flag,ch);
	else if(choice==4) {
		makeMenu(ch);
		if(flag==1){
			printf("TOPTEN\n");
			topTen(flag,"global.txt",ch);
		}
		else if(flag==2){
			printf("LATEST\n");
			latest(flag,"global.txt",ch);
		}
		else if(flag==3){
			printf("FAVOURITES\n");
			topTen(flag,ch,ch);
		}
		else if(flag==4){
			printf("SEARCH....");
			search(ch);
		}
	}
	else if(choice==5){
		makeMenu(ch);
		choices(ch);
	}
}
/*
	Function used to play song with serial number of the list shown
*/
void currentSong(TOPTEN* current,int flag, char ch[]){
	TOPTEN *temp=headTopTen;

	while(temp!=NULL){
		if(temp==current){
			printf("PLAYING %s, %s\n",temp->song,temp->artist);
			musicBar(ch);
			increment(temp->song,temp->artist,"global.txt",flag);
			increment(temp->song,temp->artist,ch,flag);
			break;
		}
		temp=temp->next;
	}
	printf("Enter 1 for Previous Song, 2 to Repeat Current Song, 3 for next song, 4 for Back, 5 for Main Menu\n");
	int choice;
	scanf("%d",&choice);
	if(choice==1) prevSong(temp,flag,ch);
	else if(choice==2) currentSong(temp,flag,ch);
	else if(choice==3) nextSong(temp,flag,ch);
	else if(choice==4) {
		makeMenu(ch);
		if(flag==1){
			printf("TOPTEN\n");
			topTen(flag,"global.txt",ch);
		}
		else if(flag==2){
			printf("LATEST\n");
			latest(flag,"global.txt",ch);
		}
		else if(flag==3){
			printf("FAVOURITES\n");
			topTen(flag,ch,ch);
		}
		else if(flag==4){
			printf("SEARCH....");
			search(ch);
		}
	}
	else if(choice==5){
		makeMenu(ch);
		choices(ch);
	}
}
/*
	Function is used to play next song to the current song .
*/
void nextSong(TOPTEN *current,int flag,char ch[]){
	TOPTEN *temp=headTopTen;
	while(temp!=NULL){
		if(temp==current){
			if(temp->next==NULL){
				printf("LAST SONG\n");
				break;
			}
			printf("PLAYING %s, %s\n",temp->next->song,temp->next->artist);
			musicBar();
			increment(temp->next->song,temp->next->artist,ch,flag);
			increment(temp->next->song,temp->next->artist,"global.txt",flag);
			break;
		}
		temp=temp->next;
	}
	printf("Enter 1 for Previous Song, 2 to Repeat Current Song, 3 for next song, 4 for Back, 5 for Main Menu\n");
	int choice;
	scanf("%d",&choice);
	if(choice==1) prevSong(temp,flag,ch);
	else if(choice==2) currentSong(temp->next,flag,ch);
	else if(choice==3) nextSong(temp->next,flag,ch);
	else if(choice==4) {
		makeMenu(ch);
		if(flag==1){
			printf("TOPTEN\n");
			topTen(flag,"global.txt",ch);
		}
		else if(flag==2){
			printf("LATEST\n");
			latest(flag,"global.txt",ch);
		}
		else if(flag==3){
			printf("FAVOURITES\n");
			topTen(flag,ch,ch);
		}
		else if(flag==4){
			printf("SEARCH....");
			search(ch);
		}
	}
	else if(choice==5){
		makeMenu(ch);
		choices(ch);
	}
}
/*
	Function prompts user to give input to play song number and then calls currentSong() to play it.
*/
void playMusic(int flag,char ch[]){
	TOPTEN *temp=headTopTen;
	int n;
	char c[2];
	printf("\nPRESS SERIAL NUMBER OF SONG TO PLAY\t\tPRESS 'b' TO RETURN TO MAIN MENU.\n");
	scanf("%s",c);
	if(strcmp(c,"b")==0)
	{
		makeMenu(ch);
		choices(ch);
	}
	else
	{
		n=atoi(c);
	}
	while(temp!=NULL){
		if(temp->sno==n){
			currentSong(temp,flag,ch);
			break;
		}
		temp=temp->next;
	}
	printf("Enter 1 for Previous Song, 2 to Repeat Current Song, 3 for next song, 4 for Back, 5 for Main Menu\n");
	int choice;
	scanf("%d",&choice);
	if(choice==1) prevSong(temp,flag,ch);
	else if(choice==2) currentSong(temp,flag,ch);
	else if(choice==3) nextSong(temp,flag,ch);
	else if(choice==4) {
		makeMenu(ch);
		if(flag==1){
			printf("TOPTEN\n");
			topTen(flag,"global.txt",ch);
		}
		else if(flag==2){
			printf("LATEST\n");
			latest(flag,"global.txt",ch);
		}
		else if(flag==3){
			printf("FAVOURITES\n");
			topTen(flag,ch,ch);
		}
		else if(flag==4){
			printf("SEARCH....");
			search(ch);
		}
	}
	else if(choice==5){
		makeMenu(ch);
		choices(ch);
	}
}

/*
	Display function displays details of the nodes of the linked list
*/
void display(TOPTEN *p){
	while(p!=NULL){
		printf("%d.) %s, %s \n",p->sno,p->song,p->artist);
		p = p->next;
	}
}
/*
	Function returns created node, with all specified parameter.
*/
TOPTEN* createNode(char song[],char artist[],char album[],char genre[],int sno,int n){
	TOPTEN *temp;
	temp = (TOPTEN*)malloc(sizeof(TOPTEN));
	temp->sno=sno+1;
	strcpy(temp->song,song);
	strcpy(temp->artist,artist);
	strcpy(temp->album,album);
	strcpy(temp->genre,genre);
	temp->count=n;
	temp->next = NULL;
	return temp;
}
/*
	Function used to create linked list out of file contents.
	First, it seperates the song, artist, album, genre, and count from a line from the file.
	Then it proceeds to add the data in a linked list
*/
void createList(char str[],int sno){
	int l=strlen(str),count=0;
	char song[100],artist[100],album[100],genre[100],num[100];
	int i,k=0,j,n=0,m=0;
	for(i=0;i<l;i++){
		if(str[i]=='^'){
			if(count==0) song[k]='\0';
			else if(count==1) artist[k]='\0';
			else if(count==2) album[k]='\0';
			else if(count==3) genre[k]='\0';
			k=0;
			count++;
		}
		if(str[i]!='^' && count==0){
			song[k++]=str[i];
		}
		else if(str[i]!='^' && count==1){
			artist[k++]=str[i];
		}
		else if(str[i]!='^' && count==2){
			album[k++]=str[i];
		}
		else if(str[i]!='^' && count==3){
			genre[k++]=str[i];
		}
		else if(str[i]=='#'){
			for(j=i+1;j<l;j++){
					num[m++]=str[j];
				}
				num[m]='\0';
				n=atoi(num);
				m=0;
				break;
		}
	}
	TOPTEN *p;
	p=createNode(song,artist,album,genre,sno,n);
	if(sno==0){
		lastTopTen=headTopTen=p;
	}
	else{
		lastTopTen->next=p;
		lastTopTen=p;
	}
}
/*
	Function to check repetitions in array. It is required as 2 songs having same count can possibly return inaccurate values.
*/
int checkinArray(int ln,int prevPos[],int q){
	for(int i=0;i<q;i++){
		if(prevPos[i]==ln)
			return 1;
	}
	return 0;
}
/*
	Picks up the first 15 strings from file and cretes a linked list.
	(In file new songs are added at the top)
*/
void latest(int flag,char fname[],char ch[]){
	FILE *fp=fopen(fname,"r");
	char str[100];
	int i=0,j=0;
	while(fscanf(fp," %[^\n]s",str)>=0){
		if(i==15) break;
		int l=strlen(str);
		int x=0;
		createList(str,i);
		printf("%d.) ",i+1);
		for(j=0;j<l;j++){
			if(str[j]=='^' && x==1){
				printf("\n");
				break;
			}
			if(str[j]!='^') printf("%c",str[j]);
			else{
				printf(", ");
				x=1;
			}
		}
		i++;
	}
	playMusic(flag,ch);
}
/*
	Searches for the most played songs by all the users and hence prints the topTen songs based on the data.
*/
void topTen(int flag,char fname[],char ch[]){
	int i,j=0,k,max2=9999,prevPos[1000],q=0;
	for(i=0;i<10;i++){
		char str[1000],st[1000];
		FILE *fp=fopen(fname,"r");
		int max=0;
		int n,ln=0,m=0,pos;
		if(flag==3) fscanf(fp," %[^\n]s",str);
		while(fscanf(fp," %[^\n]s",str)>=0){
			int l=strlen(str);
			m=0;
			char num[1000];
			for(j=0;j<l;j++){
				if(str[j]=='#'){
					for(k=j+1;k<l;k++)
						num[m++]=str[k];
					num[m]='\0';
					n=atoi(num);
					break;
				}
			}
			if(n>max && n<=max2 && checkinArray(ln,prevPos,q)==0){
				max=n;

				pos=ln;
			}
			ln++;
		}
		//printf("max:%d\n",max);
		if(max==0 && i==0)
		{
			printf("You have not played anything in your library yet..\n");
			//system("clear");
			printf("Enter 1 to Log in from another account, 2 to return to the main screen\n");
			int z;
			scanf("%d",&z);
			if(z==1) loginScreen(ch);
			if (z==2) choices(ch);
			else
			break;
		}
		if(max==0) break;
		prevPos[q++]=pos;
		max2=max;
		ln=0;
		FILE *fp2=fopen(fname,"r");

		if(flag==3) fscanf(fp2," %[^\n]s",str);
		while(fscanf(fp2," %[^\n]s",str)>=0){
			int l=strlen(str);
			int x=0;
			if(ln==pos){
				createList(str,i);
				//printf("%d.) ",i+1);
				for(j=0;j<l;j++){
					if(str[j]=='^' && x==1){
						//printf("\n");
						break;
					}
					//if(str[j]!='^') printf("%c",str[j]);
					else{
						//printf(", ");
						x=1;
					}
				}
				break;
			}
			ln++;
		}
		fclose(fp);
		fclose(fp2);
	}
}
/*
	This functions gives the predictions to what the user might like to hear based on his/her genre intersts.
	eg. if a user tends to listen to 'pop' music more, his predictions will have pop music songs.
*/
void predictions(TOPTEN* headTopTen, char genre[]){
	FILE *fp=fopen("global.txt","r");
	char str[100];
	int f=0;
	while(fscanf(fp," %[^\n]s",str)>=0){
		int l=strlen(str),count=0;
		char song[100],artist[100],album[100],genre2[100],num[100];
		int i,k=0,j,n=0,m=0;
		for(i=0;i<l;i++){
			if(str[i]=='^'){
				if(count==0) song[k]='\0';
				else if(count==1) artist[k]='\0';
				else if(count==2) album[k]='\0';
				else if(count==3) genre2[k]='\0';
				k=0;
				count++;
			}
			if(str[i]!='^' && count==0){
				song[k++]=str[i];
			}
			else if(str[i]!='^' && count==1){
				artist[k++]=str[i];
			}
			else if(str[i]!='^' && count==2){
				album[k++]=str[i];
			}
			else if(str[i]!='^' && count==3){
				genre2[k++]=str[i];
			}
			else if(str[i]=='#'){
				for(j=i+1;j<l;j++){
						num[m++]=str[j];
					}
					num[m]='\0';
					n=atoi(num);
					m=0;
					break;
			}
		}
		if(strcmp(genre,genre2)==0){
			//printf("%s %s\n",song,artist);
			createList(str,f);
			f++;
		}
	}
}
/*
	This is the Main Menu function where the user is given choices to display and play the music from the various lists offered by our music player.
*/
void choices(char ch[]){
	int n;
	system("clear");
	makeMenu(ch);
	printf("Press 1 for TOP TEN \t\t Press 2 for LATEST \t\t Press 3 for your Personalisied Library\t\t Press 4 to search\t\t Press 5 for suggestions\n");
	scanf("%d",&n);
	int flag;
	switch(n){
		case(1):
			makeMenu(ch);
			printf("\nTOP TEN OF THE WEEK :\n\n");
			topTen(1,"global.txt",ch);
			display(headTopTen);
			playMusic(1,ch);
			break;
		case(2):
			makeMenu(ch);
			printf("LATEST SONGS:-\n");
			latest(2,"global.txt",ch);
			break;
		case(3):
			makeMenu(ch);
			printf("FAVOURITES:-\n");
			topTen(3,ch,ch);
			display(headTopTen);
			playMusic(3,ch);
			break;
		case(4):
			makeMenu(ch);
			printf("SEARCH:-\n");
			search(ch);
			break;
		case(5):
			makeMenu(ch);
			printf("SUGGESTIONS:-\n");
			topTen(3,ch,ch);
			char genre[20];
			strcpy(genre,headTopTen->genre);
			predictions(headTopTen,genre);
			display(headTopTen);
			playMusic(5,ch);
	}
}
